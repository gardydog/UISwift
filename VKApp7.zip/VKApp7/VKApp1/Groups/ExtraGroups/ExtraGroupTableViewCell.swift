//
//  ExtraGroupTableViewCell.swift
//  VKApp1
//
//  Created by Mac on 22.05.2021.
//

import UIKit

class ExtraGroupTableViewCell: UITableViewCell {



}
